import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { MapPin, Phone, Mail, MessageCircle, Send, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { CONTACT_INFO } from '@/config/contact';

const formSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  phone: z.string().min(10, 'Please enter a valid phone number'),
  email: z.string().email('Please enter a valid email address'),
  preferredDate: z.string().min(1, 'Please select a preferred date'),
  preferredTime: z.string().min(1, 'Please select a preferred time'),
  matterType: z.string().min(1, 'Please select the type of legal matter'),
  message: z.string().min(10, 'Please provide more details about your matter'),
  consent: z.boolean().refine(val => val === true, 'You must agree to the privacy policy')
});

type FormData = z.infer<typeof formSchema>;

const ContactSection = () => {
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      phone: '',
      email: '',
      preferredDate: '',
      preferredTime: '',
      matterType: '',
      message: '',
      consent: false
    }
  });

  const onSubmit = async (data: FormData) => {
    setIsSubmitting(true);
    
    try {
      // Create mailto link with form data
      const subject = `Legal Consultation Request - ${data.matterType}`;
      const body = `
Name: ${data.name}
Phone: ${data.phone}
Email: ${data.email}
Preferred Date: ${data.preferredDate}
Preferred Time: ${data.preferredTime}
Matter Type: ${data.matterType}

Message:
${data.message}

This appointment request was submitted through the website contact form.
      `.trim();
      
      const mailtoLink = `mailto:${CONTACT_INFO.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      window.location.href = mailtoLink;
      
      // Reset form after submission
      form.reset();
      
    } catch (error) {
      console.error('Form submission error:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const matterTypes = [
    'Civil Matter',
    'Consumer Dispute',
    'Property & Tenancy',
    'Contract & Business',
    'Family & Matrimonial',
    'RTI & Compliance',
    'Legal Consultation',
    'Document Drafting',
    'Other'
  ];

  const timeSlots = [
    '10:00 AM', '10:30 AM', '11:00 AM', '11:30 AM',
    '12:00 PM', '12:30 PM', '02:00 PM', '02:30 PM',
    '03:00 PM', '03:30 PM', '04:00 PM', '04:30 PM',
    '05:00 PM', '05:30 PM'
  ];

  return (
    <div className="py-12 sm:py-16 lg:py-20 bg-gradient-subtle relative overflow-hidden">
      
      <div className="container mx-auto px-4 lg:px-6 relative">
        <div className="text-center space-y-2 sm:space-y-4 mb-8 sm:mb-12 lg:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-playfair font-bold mb-2 sm:mb-4">
            <span className="gradient-text">Contact &</span> <span className="gradient-text-sunset">Appointment</span>
          </h2>
          <div className="w-16 sm:w-20 lg:w-24 h-1 bg-gradient-gold rounded-full mx-auto"></div>
          <p className="text-base sm:text-lg lg:text-xl text-muted-foreground max-w-2xl mx-auto px-4">
            Ready to discuss your legal matter? Get in touch for a consultation
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6 sm:gap-8 lg:gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            {/* Get in Touch Card */}
            <div className="group relative overflow-hidden rounded-lg sm:rounded-xl lg:rounded-2xl bg-gradient-to-br from-emerald/10 to-sapphire/10 backdrop-blur-sm border border-emerald/20 shadow-jewel hover:shadow-premium transition-all duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-emerald/5 to-sapphire/5 opacity-50"></div>
              <div className="relative p-4 sm:p-6 lg:p-8">
                <div className="flex items-center space-x-2 sm:space-x-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-emerald to-emerald-light rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg">
                    <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-white" />
                  </div>
                  <h3 className="text-lg sm:text-xl lg:text-2xl font-playfair font-bold gradient-text">Get in Touch</h3>
                </div>
                
                <div className="space-y-3 sm:space-y-4 lg:space-y-6">
                  <div className="flex items-start space-x-2 sm:space-x-3 lg:space-x-4 group/item hover:bg-gradient-to-r hover:from-emerald/5 hover:to-transparent p-2 sm:p-3 rounded-lg transition-all duration-200">
                    <div className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 bg-gradient-to-r from-emerald to-emerald-light rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg">
                      <MapPin className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-semibold text-foreground gradient-text-gold">Address</p>
                      <p className="text-xs sm:text-sm lg:text-base text-muted-foreground">{CONTACT_INFO.address.city}, {CONTACT_INFO.address.state}</p>
                      <p className="text-xs sm:text-sm text-muted-foreground">Working Office: {CONTACT_INFO.address.workingOffice}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-2 sm:space-x-3 lg:space-x-4 group/item hover:bg-gradient-to-r hover:from-sapphire/5 hover:to-transparent p-2 sm:p-3 rounded-lg transition-all duration-200">
                    <div className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 bg-gradient-to-r from-sapphire to-sapphire-light rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Phone className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-semibold text-foreground gradient-text-gold">Phone</p>
                      <p className="text-xs sm:text-sm lg:text-base text-muted-foreground">+91-{CONTACT_INFO.phone}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-2 sm:space-x-3 lg:space-x-4 group/item hover:bg-gradient-to-r hover:from-ruby/5 hover:to-transparent p-2 sm:p-3 rounded-lg transition-all duration-200">
                    <div className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 bg-gradient-to-r from-ruby to-ruby-light rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Mail className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-semibold text-foreground gradient-text-gold">Email</p>
                      <p className="text-xs sm:text-sm lg:text-base text-muted-foreground">{CONTACT_INFO.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start space-x-2 sm:space-x-3 lg:space-x-4 group/item hover:bg-gradient-to-r hover:from-amethyst/5 hover:to-transparent p-2 sm:p-3 rounded-lg transition-all duration-200">
                    <div className="w-6 h-6 sm:w-8 sm:h-8 lg:w-10 lg:h-10 bg-gradient-to-r from-amethyst to-amethyst-light rounded-lg flex items-center justify-center flex-shrink-0 shadow-lg">
                      <Clock className="w-3 h-3 sm:w-4 sm:h-4 lg:w-5 lg:h-5 text-white" />
                    </div>
                    <div>
                      <p className="text-sm sm:text-base font-semibold text-foreground gradient-text-gold">Business Hours</p>
                      <p className="text-xs sm:text-sm lg:text-base text-muted-foreground">Mon–Sat, 10:00–18:00 IST</p>
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3 lg:gap-4 mt-4 sm:mt-6 lg:mt-8">
                  <Button 
                    asChild 
                    variant="emerald" 
                    size="sm" 
                    className="flex-1 text-xs sm:text-sm"
                  >
                    <a
                      href={CONTACT_INFO.whatsapp}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      <MessageCircle className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      WhatsApp Now
                    </a>
                  </Button>
                  <Button 
                    asChild 
                    variant="sapphire" 
                    size="sm" 
                    className="flex-1 text-xs sm:text-sm"
                  >
                    <a href={`tel:+91${CONTACT_INFO.phone}`}>
                      <Phone className="w-3 h-3 sm:w-4 sm:h-4 mr-1 sm:mr-2" />
                      Call
                    </a>
                  </Button>
                </div>
              </div>
            </div>

            {/* Location Card */}
            <div className="group relative overflow-hidden rounded-lg sm:rounded-xl lg:rounded-2xl bg-gradient-to-br from-topaz/10 to-gold/10 backdrop-blur-sm border border-topaz/20 shadow-gold hover:shadow-premium transition-all duration-300">
              <div className="absolute inset-0 bg-gradient-to-br from-topaz/5 to-gold/5 opacity-50"></div>
              <div className="relative p-4 sm:p-6 lg:p-8">
                <div className="flex items-center space-x-2 sm:space-x-3 mb-4 sm:mb-6">
                  <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-topaz to-topaz-light rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg">
                    <MapPin className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-white" />
                  </div>
                  <h3 className="text-lg sm:text-xl lg:text-2xl font-playfair font-bold gradient-text-gold">Location</h3>
                </div>
                <div className="space-y-3 sm:space-y-4">
                  <div className="aspect-video sm:aspect-[4/3] lg:aspect-video rounded-lg sm:rounded-xl overflow-hidden border border-topaz/30 shadow-lg h-32 sm:h-40 lg:h-auto">
                    <iframe
                      title="Purulia Court Location"
                      src={`https://www.google.com/maps?q=${encodeURIComponent(CONTACT_INFO.address.plusCode)}&output=embed`}
                      className="w-full h-full"
                      loading="lazy"
                      referrerPolicy="no-referrer-when-downgrade"
                    />
                  </div>
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-2 sm:p-3 lg:p-4 bg-gradient-to-r from-topaz/5 to-gold/5 rounded-lg border border-topaz/20 gap-2 sm:gap-0">
                    <span className="text-xs sm:text-sm lg:text-base text-muted-foreground font-medium">{CONTACT_INFO.address.workingOffice}</span>
                    <Button 
                      asChild 
                      variant="outline-gradient" 
                      size="sm"
                      className="text-xs sm:text-sm w-full sm:w-auto"
                    >
                      <a 
                        href={CONTACT_INFO.address.mapsUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                      >
                        Open in Google Maps
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Appointment Form */}
          <div className="group relative overflow-hidden rounded-lg sm:rounded-xl lg:rounded-2xl bg-gradient-to-br from-sapphire/10 to-sapphire-light/10 backdrop-blur-sm border border-sapphire/20 shadow-jewel hover:shadow-jewel transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-to-br from-sapphire/5 to-sapphire-light/5 opacity-50"></div>
            <div className="relative p-4 sm:p-6 lg:p-8">
              <div className="flex items-center space-x-2 sm:space-x-3 mb-4 sm:mb-6 lg:mb-8">
                <div className="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 bg-gradient-to-r from-sapphire to-sapphire-light rounded-lg sm:rounded-xl flex items-center justify-center shadow-lg">
                  <Send className="w-4 h-4 sm:w-5 sm:h-5 lg:w-6 lg:h-6 text-white" />
                </div>
                <h3 className="text-lg sm:text-xl lg:text-2xl font-playfair font-bold gradient-text">Book Appointment</h3>
              </div>
              
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3 sm:space-y-4 lg:space-y-6">
                  <div className="grid md:grid-cols-2 gap-3 sm:gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Full Name *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Your full name" 
                              {...field}
                              className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Phone Number *</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="+91 XXXXX XXXXX" 
                              {...field}
                              className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Email Address *</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="your.email@example.com" 
                            type="email" 
                            {...field}
                            className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="grid md:grid-cols-2 gap-3 sm:gap-4">
                    <FormField
                      control={form.control}
                      name="preferredDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Preferred Date *</FormLabel>
                          <FormControl>
                            <Input 
                              type="date" 
                              {...field} 
                              min={new Date().toISOString().split('T')[0]}
                              className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="preferredTime"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Preferred Time *</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm">
                                <SelectValue placeholder="Select time" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent className="bg-background/95 backdrop-blur-sm border-sapphire/20 shadow-premium z-50">
                              {timeSlots.map((time) => (
                                <SelectItem 
                                  key={time} 
                                  value={time} 
                                  className="text-sm hover:bg-sapphire/10 hover:text-sapphire focus:bg-sapphire/10 focus:text-sapphire"
                                >
                                  {time}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="matterType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Type of Legal Matter *</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger className="text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm">
                              <SelectValue placeholder="Select matter type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent className="bg-background/95 backdrop-blur-sm border-sapphire/20 shadow-premium z-50">
                            {matterTypes.map((type) => (
                              <SelectItem 
                                key={type} 
                                value={type} 
                                className="text-sm hover:bg-sapphire/10 hover:text-sapphire focus:bg-sapphire/10 focus:text-sapphire"
                              >
                                {type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="message"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-sm sm:text-base text-foreground font-semibold">Brief Description *</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Please provide a brief description of your legal matter..."
                            className="min-h-[80px] sm:min-h-[100px] lg:min-h-[120px] text-sm sm:text-base border-sapphire/30 focus:border-sapphire focus:ring-sapphire/20 bg-background/80 backdrop-blur-sm"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="flex items-start space-x-2 sm:space-x-3 p-3 sm:p-4 border border-sapphire/30 rounded-lg bg-gradient-to-r from-sapphire/5 to-transparent">
                    <Checkbox 
                      id="consent" 
                      checked={form.watch('consent')}
                      onCheckedChange={(checked) => form.setValue('consent', checked as boolean)}
                      className="border-sapphire/50 data-[state=checked]:bg-sapphire data-[state=checked]:border-sapphire mt-0.5"
                    />
                    <label htmlFor="consent" className="text-xs sm:text-sm leading-relaxed text-muted-foreground cursor-pointer">
                      I agree to the privacy policy and consent to the collection of my personal information for legal consultation purposes.
                    </label>
                  </div>
                  
                  <Button 
                    type="submit" 
                    variant="sapphire" 
                    size="lg" 
                    disabled={isSubmitting}
                    className="w-full text-sm sm:text-base"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-3 w-3 sm:h-4 sm:w-4 border-b-2 border-white mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        <Send className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                        Send Appointment Request
                      </>
                    )}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactSection;