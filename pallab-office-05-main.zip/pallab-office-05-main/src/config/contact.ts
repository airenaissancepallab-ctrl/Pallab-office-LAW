export const CONTACT_INFO = {
  email: 'pallabgorain50@gmail.com',
  phone: '8145760110',
  whatsapp: 'https://wa.me/qr/SOTWGEYA74EMM1',
  address: {
    city: 'Purulia',
    state: 'West Bengal',
    workingOffice: 'Purulia Court',
    plusCode: 'Purulia Court, West Bengal, India',
    mapsUrl: 'https://maps.google.com/?q=Purulia+Court+West+Bengal+India'
  }
};