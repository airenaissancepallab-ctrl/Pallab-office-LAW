interface ZapierFormData {
  name: string;
  email: string;
  phone: string;
  message: string;
  timestamp: string;
  source_url: string;
  user_agent: string;
  recipient_email: string;
}

interface ZapierAppointmentData {
  name: string;
  email: string;
  phone: string;
  preferredDate: string;
  preferredTime: string;
  matterType: string;
  message: string;
  timestamp: string;
  source_url: string;
  user_agent: string;
  recipient_email: string;
}

export const sendToZapier = async (formData: Omit<ZapierFormData, 'timestamp' | 'source_url' | 'user_agent' | 'recipient_email'>): Promise<void> => {
  const webhookUrl = import.meta.env.VITE_ZAPIER_WEBHOOK_URL;
  
  if (!webhookUrl) {
    throw new Error('Zapier webhook URL not configured. Please set VITE_ZAPIER_WEBHOOK_URL in your environment variables.');
  }

  const payload: ZapierFormData = {
    ...formData,
    timestamp: new Date().toISOString(),
    source_url: window.location.href,
    user_agent: navigator.userAgent,
    recipient_email: 'pallabgorain50@gmail.com'
  };

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    mode: 'no-cors', // Handle CORS for Zapier webhooks
    body: JSON.stringify(payload),
  });

  // Note: With no-cors mode, we can't check response status
  // The webhook will either work or fail silently
  console.log('Contact form submitted to Zapier:', payload);
};

export const sendAppointmentToZapier = async (formData: Omit<ZapierAppointmentData, 'timestamp' | 'source_url' | 'user_agent' | 'recipient_email'>): Promise<void> => {
  const webhookUrl = import.meta.env.VITE_ZAPIER_WEBHOOK_URL;
  
  if (!webhookUrl) {
    throw new Error('Zapier webhook URL not configured. Please set VITE_ZAPIER_WEBHOOK_URL in your environment variables.');
  }

  const payload: ZapierAppointmentData = {
    ...formData,
    timestamp: new Date().toISOString(),
    source_url: window.location.href,
    user_agent: navigator.userAgent,
    recipient_email: 'pallabgorain50@gmail.com'
  };

  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    mode: 'no-cors', // Handle CORS for Zapier webhooks
    body: JSON.stringify({
      ...payload,
      form_type: 'appointment' // Add identifier for appointment forms
    }),
  });

  // Note: With no-cors mode, we can't check response status
  // The webhook will either work or fail silently
  console.log('Appointment request submitted to Zapier:', payload);
};