import DOMPurify from 'dompurify';

/**
 * Security utility functions for input validation and sanitization
 */

/**
 * Sanitize HTML content to prevent XSS attacks
 * @param dirty - The untrusted HTML string
 * @returns Sanitized HTML string
 */
export const sanitizeHtml = (dirty: string): string => {
  return DOMPurify.sanitize(dirty, {
    ALLOWED_TAGS: [], // No HTML tags allowed
    ALLOWED_ATTR: [], // No attributes allowed
    KEEP_CONTENT: true, // Keep text content
  });
};

/**
 * Validate email format with security considerations
 * @param email - Email string to validate
 * @returns Boolean indicating if email is valid
 */
export const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email) && email.length <= 254;
};

/**
 * Validate phone number format
 * @param phone - Phone string to validate
 * @returns Boolean indicating if phone is valid
 */
export const isValidPhone = (phone: string): boolean => {
  const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,15}$/;
  return phoneRegex.test(phone);
};

/**
 * Validate name to prevent injection attacks
 * @param name - Name string to validate
 * @returns Boolean indicating if name is valid
 */
export const isValidName = (name: string): boolean => {
  const nameRegex = /^[a-zA-Z\s.'-]{2,100}$/;
  return nameRegex.test(name);
};

/**
 * Enhanced rate limiting for form submissions with progressive delays
 */
class EnhancedRateLimiter {
  private submissions: number[] = [];
  private readonly maxAttempts = 5;
  private readonly timeWindow = 15 * 60 * 1000; // 15 minutes
  private failedAttempts: number = 0;

  canSubmit(): boolean {
    const now = Date.now();
    // Remove old submissions outside the time window
    this.submissions = this.submissions.filter(time => now - time < this.timeWindow);
    
    // Progressive delay based on failed attempts
    const delay = this.getProgressiveDelay();
    const lastSubmission = this.submissions[this.submissions.length - 1] || 0;
    
    if (now - lastSubmission < delay) {
      return false;
    }
    
    if (this.submissions.length >= this.maxAttempts) {
      return false;
    }
    
    this.submissions.push(now);
    return true;
  }

  private getProgressiveDelay(): number {
    // Progressive delay: 0s, 5s, 10s, 30s, 60s
    const delays = [0, 5000, 10000, 30000, 60000];
    return delays[Math.min(this.failedAttempts, delays.length - 1)];
  }

  getRemainingTime(): number {
    if (this.submissions.length < this.maxAttempts) {
      const delay = this.getProgressiveDelay();
      const lastSubmission = this.submissions[this.submissions.length - 1] || 0;
      const remainingDelay = Math.max(0, delay - (Date.now() - lastSubmission));
      
      if (remainingDelay > 0) {
        return remainingDelay;
      }
      
      return 0;
    }
    
    const oldestSubmission = Math.min(...this.submissions);
    return Math.max(0, this.timeWindow - (Date.now() - oldestSubmission));
  }

  recordFailedAttempt(): void {
    this.failedAttempts++;
  }

  reset(): void {
    this.submissions = [];
    this.failedAttempts = 0;
  }

  getStatus(): { 
    attemptsRemaining: number; 
    nextAttemptIn: number;
    isBlocked: boolean;
  } {
    const now = Date.now();
    this.submissions = this.submissions.filter(time => now - time < this.timeWindow);
    
    const delay = this.getProgressiveDelay();
    const lastSubmission = this.submissions[this.submissions.length - 1] || 0;
    const nextAttemptIn = Math.max(0, delay - (now - lastSubmission));
    
    return {
      attemptsRemaining: Math.max(0, this.maxAttempts - this.submissions.length),
      nextAttemptIn,
      isBlocked: this.submissions.length >= this.maxAttempts || nextAttemptIn > 0
    };
  }
}

export const formRateLimiter = new EnhancedRateLimiter();

/**
 * Security monitoring utilities
 */
class SecurityMonitor {
  private static instance: SecurityMonitor;
  private events: Array<{
    type: string;
    timestamp: number;
    details: any;
  }> = [];

  static getInstance(): SecurityMonitor {
    if (!SecurityMonitor.instance) {
      SecurityMonitor.instance = new SecurityMonitor();
    }
    return SecurityMonitor.instance;
  }

  logSecurityEvent(type: string, details: any = {}): void {
    const event = {
      type,
      timestamp: Date.now(),
      details
    };
    
    this.events.push(event);
    console.warn(`[SECURITY] ${type}:`, details);
    
    // Keep only last 100 events to prevent memory issues
    if (this.events.length > 100) {
      this.events = this.events.slice(-100);
    }
  }

  getSecurityEvents(): Array<any> {
    return [...this.events];
  }

  detectSuspiciousActivity(formData: any): boolean {
    const suspicious = [];
    
    // Check for potential SQL injection patterns
    const sqlPatterns = /(\bUNION\b|\bSELECT\b|\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bDROP\b)/i;
    Object.values(formData).forEach((value: any) => {
      if (typeof value === 'string' && sqlPatterns.test(value)) {
        suspicious.push('SQL_INJECTION_ATTEMPT');
      }
    });
    
    // Check for potential XSS patterns
    const xssPatterns = /<script|javascript:|onload=|onerror=/i;
    Object.values(formData).forEach((value: any) => {
      if (typeof value === 'string' && xssPatterns.test(value)) {
        suspicious.push('XSS_ATTEMPT');
      }
    });
    
    // Check for unusually long inputs (potential buffer overflow)
    Object.entries(formData).forEach(([key, value]: [string, any]) => {
      if (typeof value === 'string' && value.length > 2000) {
        suspicious.push(`OVERSIZED_INPUT_${key.toUpperCase()}`);
      }
    });
    
    if (suspicious.length > 0) {
      this.logSecurityEvent('SUSPICIOUS_FORM_SUBMISSION', {
        patterns: suspicious,
        formData: Object.keys(formData)
      });
      return true;
    }
    
    return false;
  }
}

export const securityMonitor = SecurityMonitor.getInstance();

/**
 * Check if a URL is safe for external linking
 * @param url - URL to validate
 * @returns Boolean indicating if URL is safe
 */
export const isSafeUrl = (url: string): boolean => {
  try {
    const parsedUrl = new URL(url);
    // Only allow HTTP(S) protocols
    return ['http:', 'https:'].includes(parsedUrl.protocol);
  } catch {
    return false;
  }
};

/**
 * Enhanced security constants for the application
 */
export const SECURITY_CONFIG = {
  MAX_FILE_SIZE: 5 * 1024 * 1024, // 5MB
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/webp'],
  MAX_MESSAGE_LENGTH: 1000,
  MAX_NAME_LENGTH: 100,
  MAX_EMAIL_LENGTH: 254,
  MAX_PHONE_LENGTH: 15,
  
  // New security thresholds
  MAX_FORM_SUBMISSIONS_PER_HOUR: 10,
  SUSPICIOUS_ACTIVITY_THRESHOLD: 3,
  SECURITY_LOG_RETENTION_HOURS: 24,
} as const;

/**
 * Validate form data against security threats
 * @param formData - Form data object to validate
 * @returns Security validation result
 */
export const validateFormSecurity = (formData: Record<string, any>): {
  isValid: boolean;
  issues: string[];
  sanitizedData: Record<string, any>;
} => {
  const issues: string[] = [];
  const sanitizedData: Record<string, any> = {};
  
  // Detect suspicious activity
  const isSuspicious = securityMonitor.detectSuspiciousActivity(formData);
  if (isSuspicious) {
    issues.push('Suspicious activity detected');
  }
  
  // Sanitize and validate each field
  Object.entries(formData).forEach(([key, value]) => {
    if (typeof value === 'string') {
      const sanitized = sanitizeHtml(value.trim());
      sanitizedData[key] = sanitized;
      
      // Check if sanitization changed the content significantly
      if (sanitized !== value.trim() && sanitized.length < value.trim().length * 0.8) {
        issues.push(`Potentially malicious content in ${key}`);
      }
    } else {
      sanitizedData[key] = value;
    }
  });
  
  return {
    isValid: issues.length === 0,
    issues,
    sanitizedData
  };
};
